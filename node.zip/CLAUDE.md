# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

**ValiTools** — a ComfyUI custom node collection (currently one node, more planned). The node `VSmartPrompt` is a Dynamic Prompts processor with a rich-text (syntax-highlighted) prompt editor: combinations, wildcards, reusable variables, inline comments, and post-run selection highlighting. Outputs are `prompt` and `original_prompt` only — LoRA loading and model/clip passthrough were deliberately removed; lora tags are merely stripped from the output text.

This package originated as a rename of the user's "Silver fork" of ComfyUI-RichText_BasicDynamicPrompts. The fork itself lives at `/home/vangel/apps/ComfyUI2/ComfyUI-Easy-Install/ComfyUI/custom_nodes/comfyui-richtext_prompts` (own git repo, node id `SILVER_BasicDynamicPrompts`, routes `/silver_basicdynamicprompts/`) and must stay independent — both packages can be installed side by side because this one uses node id `VSmartPrompt` and routes `/valitools/`. Do not sync files wholesale between the two directories.

There is no build system, test suite, or linter. `nodes.py` imports `server`/`aiohttp`, which only exist inside a running ComfyUI. Python changes require a ComfyUI restart; JS changes a browser reload (`web/` is served via `WEB_DIRECTORY` in `__init__.py`).

## Architecture

Two halves that must stay in sync:

**Backend (`nodes.py`)** — `dynamic_prompts()` resolves iteratively: wildcards (`__file__`, case-insensitive, subfolders), combinations (`{a|b}` with `N::` weights, innermost-first), then variables and a final `_fix_prompt()` cleanup. Distinctive machinery:
- **Source maps** (`return_trace=True`, always used by the node): every text mutation maintains parallel `source_map`/`wildcard_origin_map` lists so the frontend can white-mark selected branches (`selected_ranges`) and show resolved wildcard tooltips (`wildcard_resolutions`) after a run. Any new text transformation MUST maintain these maps or trace features silently break.
- **Variables**: three assignment forms — `{a|b}==<name>` (handled at combination resolution, keeps source maps when the value equals the branch text), `__file__==<name>`, and `word==<name>` (captured by `_capture_literal_assignments()` AFTER the resolution loop, so branch-inner word assignments only fire for the selected branch). Reference substitution (`_substitute_variables`) runs ONLY after the loop — substituting earlier eats pending `word==<name>` assignments (there is a `==`-lookback guard for the same reason). Values are rolled once and constant.
- **Comments**: single `#` runs to end of line OR to a closing standalone `#` (inline `#comment#`); `##`/`###` always to end of line (`_find_comment_end`).
- Routes on `PromptServer` under `/valitools/`: `get_wildcard_files`, `validate_wildcards`, `quick_open_wildcard` (creates missing files).

**Frontend (`web/nodes/nodes.js`)** — extension keyed on `nodeData.name === "VSmartPrompt"`. Hides the `prompt` widget, overlays a contentEditable editor; every edit flows innerText → `fixCommentBody()` → widget value → `highlight()` → innerHTML with plain-text cursor save/restore. `highlight()` uses protect/restore tokens (`@@@<nonce>_TOKENn@@@`); selected-range markers are ``/`` sentinels applied before highlighting. Variable autocomplete (`web/widgets/autocomplete_dropdown.js`): typing `<` opens a dropdown of assigned variables; the keydown handler routes Up/Down/Enter/Tab/Esc to it while open.

**Sync contract**: the variable regexes (`==<name>` assignment suffix, `<name>` reference, word-assignment form) exist in both `nodes.py` and `nodes.js`. Change one → change all.

## Compatibility constraints

- `SILVER_SERIALIZED_WIDGET_COUNT = 11`, the index-based `restoreSavedWidgetValues()` mapping, and the hidden placeholder inputs (`available_loras_stem`, `load_loras_from_prompt`, …) preserve the widget layout inherited from the fork. Internal `silver`-prefixed JS identifiers are intentional — in particular `window.comfy_silver_weight_listener_added` is shared with the fork so only one global CTRL+arrow listener registers when both packages are installed.
- `normalize_wildcard_directory()` remaps legacy saved wildcard paths; applied on node input and routes.

## Versioning

Version lives in `pyproject.toml`. Every release gets a changelog entry at the top of `README.md`.

## Transition notes (written 2026-08-07, when this folder was still `~/apps/comfyui-richtext_prompts`)

This package was created on 2026-08-07 by renaming a copy of the user's "Silver fork" (see below). The user then renamed this folder itself; if you are reading this, you are probably in the new location. State at hand-off:

- **This package**: v1.0.0, complete and smoke-tested (node registration, variables, trace paths all verified). **No git repo yet** — offer `git init` + initial commit as a first step.
- **The live fork** (do NOT touch its interface): `/home/vangel/apps/ComfyUI2/ComfyUI-Easy-Install/ComfyUI/custom_nodes/comfyui-richtext_prompts`, own git repo, node id `SILVER_BasicDynamicPrompts`, routes `/silver_basicdynamicprompts/`, outputs only `prompt, original_prompt` (prompt = slot 0), no model/clip — the user's workflows depend on exactly that. `/home/vangel/Desktop/ComfyUI-Easy-Install/...` is a symlink to it. It has **uncommitted changes** (the variables feature, v4.1.0) pending a commit once the user confirms in-app testing.
- **Never copy files wholesale between this package and the fork.** On 2026-08-07 such a sync overwrote the fork and broke every workflow (output slot indexes shifted); it was fixed via `git stash` + a proper port. Something/someone performed that sync — cause never identified, stay alert. Engine fixes usually belong in BOTH packages (ported, not copied); the shared parts are the variables engine, source-map trace machinery, and inline `#comment#` handling.
- **Variables semantics** (user's core requirement: rolled ONCE, constant everywhere): three assignment forms — `{a|b}==<name>`, `__file__==<name>`, and plain `word==<name>` (captured post-resolution so branch-inner assignments only fire for the selected branch). Reference substitution runs only AFTER the resolution loop (substituting earlier eats pending word assignments — there is a `==`-lookback guard). The user actively writes patterns like `her {{left breast|right breast}==<part>, ...|stomach==<part>, ...}` — keep that consistent.
- Session memory from before the rename lives in `/home/vangel/.claude/projects/-home-vangel-apps-comfyui-richtext-prompts/memory/` (files `fork-vs-upstream-dirs.md`, `variables-feature-semantics.md`) — the new folder path means it will not auto-load; consult/migrate it if needed.
- The user communicates tersely and prefers caveman-style brevity in replies; ComfyUI runs from the ComfyUI2/Desktop-symlink install; Python changes need a ComfyUI restart, JS changes a browser hard-reload.
