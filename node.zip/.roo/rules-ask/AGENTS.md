# AGENTS.md (ask mode)

See root AGENTS.md for invariants. Ask/documentation context:

- **CLAUDE.md is the authoritative narrative** (history, fork origin, variable semantics). This AGENTS.md is the distilled invariant list; when they seem to conflict, CLAUDE.md has the "why".
- **The package is a rename, not a cleanroom rewrite.** It is the user's "Silver fork" of ComfyUI-RichText_BasicDynamicPrompts, renamed to ValiTools. That's why: the node is `VSmartPrompt`, routes are `/valitools/`, but internal JS identifiers keep `silver`/`SILVER_` prefixes and there's a `SILVER_SERIALIZED_WIDGET_COUNT = 11` legacy widget layout. These are NOT inconsistencies to "fix".
- **README.md changelog is at the TOP** (newest first), not the bottom — version history is read there, not in a CHANGELOG file.
- **No git repo was guaranteed at hand-off**; don't assume git history exists for archaeology.
- **User's real variable pattern** (from CLAUDE.md): `her {{left breast|right breast}==<part>, ...|stomach==<part>, ...}` — when explaining variable semantics, use this shape, not a toy example.
- **The user prefers caveman-style brevity.** Short, direct answers; avoid filler.
- Session memory from before the rename lives at `/home/vangel/.claude/projects/-home-vangel-apps-comfyui-richtext-prompts/memory/` (won't auto-load now).
