# AGENTS.md (code mode)

See root AGENTS.md for invariants. Code-specific:

- Python↔JS regex contract: `VARIABLE_ASSIGN_PATTERN`, `VARIABLE_REF_PATTERN`, `LITERAL_ASSIGN_PATTERN`, `GUARD_BEFORE_PATTERN`, `GUARD_SCAN_PATTERN` in `nodes.py` ↔ `VARIABLE_ASSIGN_REGEX`/`VARIABLE_REF_REGEX`/`GUARD_REGEX` etc. in `web/nodes/nodes.js`. Change one → change all, same semantics.
- Any new text mutation in `dynamic_prompts()` must update `source_map`/`wildcard_origin_map` in parallel (helpers `_append_selected_ranges`, `_split_lines_with_map`, `_join_text_segments` exist for this).
- Variable substitution stays post-loop (`_substitute_variables`); `word==<name>` capture stays post-resolution (`_capture_literal_assignments`).
- `SILVER_SERIALIZED_WIDGET_COUNT = 11` index-based widget restore in nodes.js — hidden placeholder inputs in `INPUT_TYPES` preserve legacy layout; don't reorder.
- Keep `silver`-prefixed JS identifiers when touching inherited code (`window.comfy_silver_weight_listener_added` is shared with the fork).
- Python: snake_case, module-level compiled `re` patterns, `str | tuple[...]` type hints, node classes with `@classmethod INPUT_TYPES` + `main()` + optional `check_lazy_status` for lazy `forceInput` inputs.
- JS: plain ES modules, `import { app } from "../../../scripts/app.js"`, `app.registerExtension` keyed on exact `nodeData.name`.
- Release: bump `pyproject.toml` version + changelog entry at TOP of `README.md`.
