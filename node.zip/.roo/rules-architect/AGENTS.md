# AGENTS.md (architect mode)

See root AGENTS.md for invariants. Architectural constraints:

- **Two-layer system with a hard sync seam.** Backend `nodes.py` (resolution) and frontend `web/nodes/nodes.js` (editor/highlight) are coupled through (a) the shared variable/guard regexes and (b) the trace payload `selected_ranges` + `wildcard_resolutions` returned in the `ui` dict. Any feature touching both sides must change both halves atomically — they will not fail loudly if one lags.
- **`dynamic_prompts()` is the single source of truth for text transformation.** It's iterative (max 30 passes), innermost-first for combinations, and returns either `str` or `(str, selected_ranges, wildcard_resolutions)` depending on `return_trace`. The node always uses the trace form. Don't add a second transformation path that bypasses it.
- **Ordering is load-bearing:** wildcards → combinations → literal `word==` capture (between passes) → [loop ends] → `_capture_literal_assignments` → `_sweep_guards` → `_substitute_variables` → `_fix_prompt`. Reordering silently changes which assignments fire.
- **Widget layout is a public contract.** 11 serialized widgets, index-based restore, hidden placeholder inputs in `INPUT_TYPES` — the frontend `restoreSavedWidgetValues()` and `onConfigure`/`onSerialize` slicing all depend on these exact indexes.
- **Coexistence is an architectural requirement, not a nicety.** The Silver fork installs alongside this package in the same ComfyUI. Anything global (the `window.comfy_silver_weight_listener_added` guard, node id, route prefix) must stay fork-safe.
- **Lazy-evaluation architecture** for `VSmartPrompt` (in1–in4 via `forceInput` + `check_lazy_status`) and `VRandomSelector` (`input_1`–`input_30`, `AnyType`). New inputs should follow the lazy pattern so unused upstream branches don't force execution.
- **No build/test/lint layer** — architectural safety currently comes entirely from the invariants in root AGENTS.md plus manual in-app verification.
