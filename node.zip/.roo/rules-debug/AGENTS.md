# AGENTS.md (debug mode)

See root AGENTS.md for invariants. Debug-specific:

- **Python change needs a ComfyUI restart** — a hot-reload won't pick up `nodes.py`/`vfile_random.py`/`vrandom_selector.py`. JS change needs only a browser hard-reload. If "my Python fix didn't work", first suspect a stale process, not the code.
- **Silent breakage is the norm, not the exception.** The source-map trace (`source_map`/`wildcard_origin_map`) breaks without any error if a new text mutation forgets to update it — symptom is missing white selection marks / dead wildcard tooltips after a run, no exception.
- **Variable substitution bug signature:** substituting `<name>` references BEFORE the resolution loop eats pending `word==<name>` assignments. If a variable suddenly resolves to an empty string or the raw `<name>`, check the `==`-lookback guard and loop ordering.
- **RNG bias:** if nested picks look correlated or non-uniform, check whether code reseeds `rng` mid-run — only `rng = random.Random(seed)` at the top is allowed.
- **Lazy input gotcha (`in1`–`in4`):** `check_lazy_status` only requests inputs actually referenced in the text. On a run where this node is skipped (unused upstream branch), the editor's white marks are intentionally cleared — that's `execution_cached`/`execution_done` listeners in nodes.js, not a bug.
- **Wildcard file not found:** check `normalize_wildcard_directory()` is still applied to BOTH the node input and the `/valitools/` routes — it remaps legacy saved paths.
- **VFileRandom:** state in `vfile_random_state.json`; if the bag seems stale, that JSON (thread-locked) is the source of truth — deleting it resets the cycle.
- **Two installs side by side:** the Silver fork at `.../custom_nodes/comfyui-richtext_prompts` runs the same engine with different node id/routes. When debugging "why does my workflow break", confirm which node (`VSmartPrompt` vs `SILVER_BasicDynamicPrompts`) the workflow actually uses — a fix in the wrong package does nothing.
