# AGENTS.md

This file provides guidance to agents when working with code in this repository.

ValiTools — ComfyUI custom node package (`VSmartPrompt`, `VFileRandom`, `VRandomSelector`). No build system, no tests, no linter. See CLAUDE.md for full history; the user prefers terse, caveman-style replies.

## Running / verifying
- No test suite. Python is only importable inside a running ComfyUI (`nodes.py` imports `server`/`aiohttp`). Best local check: `python -m py_compile nodes.py` or import inside ComfyUI.
- Python change → ComfyUI restart. JS change → browser hard-reload only.

## Critical invariants (break these, workflows silently break)
- Fork coexistence: this package is a rename of the "Silver fork" of RichText_BasicDynamicPrompts, which still lives at `/home/vangel/apps/ComfyUI2/ComfyUI-Easy-Install/ComfyUI/custom_nodes/comfyui-richtext_prompts` (node id `SILVER_BasicDynamicPrompts`, routes `/silver_basicdynamicprompts/`). Both install side by side — keep node id `VSmartPrompt` and routes `/valitools/`. **Never copy files wholesale between the two** (once did; broke every workflow). Engine fixes get *ported*, not copied.
- Python↔JS regex sync contract: variable/guard patterns exist in BOTH `nodes.py` (`VARIABLE_ASSIGN_PATTERN`, `VARIABLE_REF_PATTERN`, `LITERAL_ASSIGN_PATTERN`, `GUARD_*_PATTERN`) and `web/nodes/nodes.js`. Change one → change all.
- Source-map trace: every text mutation inside `dynamic_prompts()` MUST maintain the parallel `source_map`/`wildcard_origin_map` lists, or the editor's selected-range marks and wildcard tooltips silently break.
- Variable reference substitution runs ONLY after the resolution loop (earlier eats pending `word==<name>` assignments — there is an `==`-lookback guard for that). Values rolled once, constant.
- Single RNG stream per run: `rng = random.Random(seed)` — never reseed mid-run (v1.5.1 bias bug).
- Widget layout: `SILVER_SERIALIZED_WIDGET_COUNT = 11`, index-based `restoreSavedWidgetValues()` in nodes.js, hidden placeholder inputs in `INPUT_TYPES` — don't reorder/remove. `silver`-prefixed JS identifiers are intentional; `window.comfy_silver_weight_listener_added` is shared with the fork.
- `normalize_wildcard_directory()` must keep being applied on node input AND all `/valitools/` routes (remaps legacy saved paths).
- VFileRandom state lives in `vfile_random_state.json` next to the node — mid-cycle file additions join the bag, deletions are dropped.

## Code style
- Python: snake_case; module-level compiled `re` patterns; type hints on public functions (`str | tuple[...]` style); nodes as classes with `@classmethod INPUT_TYPES`, `main()`, optional `check_lazy_status` (lazy `forceInput` inputs).
- JS: plain ES modules, no build step; import app via `import { app } from "../../../scripts/app.js"`; extensions via `app.registerExtension` keyed on exact `nodeData.name`; keep `silver`-prefixed identifiers when touching inherited code.
- Versioning: version in `pyproject.toml`; every release gets a changelog entry at the TOP of `README.md`.
